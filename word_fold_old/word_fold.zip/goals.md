1. Change the css and html 
    - make it nice using complentatry colors
    - make it bad using colors that clash
    - make the page switch between black and white every 50 milliseconds
    - make the background and foreground colors very similar so no text is readable

2. Make a way to select the board
    - input radio button
    - 3 regular buttons
    - number input and button
    - 1 button that picks a random board

3. Add or subtract rules
    - word length cannot exceed 7
    - check for a win or lose
    - score?
    - can now move into empty squares
    - other rules?